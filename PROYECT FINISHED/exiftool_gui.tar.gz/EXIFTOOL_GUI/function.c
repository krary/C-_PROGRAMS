#include "library.h"
void init_event(Window *w,Input_usr *i){
    
    
	SDL_Event event;
	w->run = 1;
	i->msg[0] = '\0';
	i->run = &w->run;
    strcpy(i->text_0,"Wating for incoming data");
    init_input_usr(i,w);
    i->rect.x = 10;
    i->rect.y = 10 + 35;
    i->index_word_bool = false;
    SDL_StartTextInput();
	

    while(w->run == 1){
    	while(SDL_PollEvent(&event)){
    		if(event.type == SDL_QUIT){
    			w->run = 0;
    		}
    		
    		if(event.type == SDL_KEYDOWN){
    		    if((SDL_GetModState() & KMOD_CTRL) && event.key.keysym.sym == SDLK_v){
    		       char *texto = SDL_GetClipboardText();
    		       if(texto){
    		     
    		        paste_text(i->msg,texto,&i->index_word_character);
    		        i->index_word_character += (strlen(texto)-1);
    		        
    		         			        int width,high;
    		         			        char tmp_buffer[1024*1024];
    		         			        memset(tmp_buffer,0,sizeof(tmp_buffer));
    		         			        memcpy(tmp_buffer,i->msg,i->index_word_character);
    		         			        ttf_size(w->font,tmp_buffer,&width,&high);
    		         			        i->cursor_pos_x = i->rect.x + width+1;
    		        
    		       	i->msg[strcspn(i->msg,"\n")]='\0';
    		       	
    		       	init_input_usr(i,w);
    		       	SDL_free(texto);
    		       }
    		    }
    		  
    			switch(event.key.keysym.sym){
                  case SDLK_RIGHT:
                       i->index_word_character++;
                       //RECALCULANDO i->cursor_pos_x
                       int width,high;
                       char tmp_buffer[1024*1024];
                       memset(tmp_buffer,0,sizeof(tmp_buffer));
                       memcpy(tmp_buffer,i->msg,i->index_word_character);
                       ttf_size(w->font,tmp_buffer,&width,&high);
                       i->cursor_pos_x = i->rect.x + width+1;
                       init_input_usr(i,w);
                       break;
                       
    			    case SDLK_LEFT:
    			    if(i->index_word_character > 0){
    			        i->index_word_character--;
    			        i->index_word_bool = true;
    			        //RECALCULANDO i->cursor_pos_x
    			        int width,high;
    			        char tmp_buffer[1024*1024];
    			        memset(tmp_buffer,0,sizeof(tmp_buffer));
    			        memcpy(tmp_buffer,i->msg,i->index_word_character);
    			        ttf_size(w->font,tmp_buffer,&width,&high);
    			        i->cursor_pos_x = i->rect.x + width+1;
    			        
    			        init_input_usr(i,w);
    			        }break;
    			  
    			    case SDLK_UP:
    			       
    			       if(strlen(i->text_0) > 0 && strlen(i->msg) == 0 && strlen(i->text_01) > 0){
    			        strcat(i->msg,i->text_01);
    			        memset(i->text_0,0,sizeof(i->text_0));
    			       	init_input_usr(i,w);
    			       }
    			       break;
    				case SDLK_ESCAPE:
    					w->run = 0;
    					break;
    				case SDLK_BACKSPACE:
    				    
    				    if((strlen(i->msg) >0)){
    					
    					if(!i->index_word_bool)i->msg[i->index_word_character -1] = '\0';
                        if(i->index_word_bool&& i->index_word_character >0){
                        	size_t tam = strlen(i->msg);
                        	memmove(&i->msg[i->index_word_character-1],
                        	        &i->msg[i->index_word_character],
                        	        tam - i->index_word_character +1);
                        	        i->index_word_character --;

                            
                              			        int width,high;
                              			        char tmp_buffer[1024*1024];
                              			        memset(tmp_buffer,0,sizeof(tmp_buffer));
                              			        memcpy(tmp_buffer,i->msg,i->index_word_character);
                              			        ttf_size(w->font,tmp_buffer,&width,&high);
                              			        i->cursor_pos_x = i->rect.x + width+1;
                        	        
                        }
    					if(strlen(i->msg)< ((size_t)i->index_word_character)){i->index_word_character--;}
    			        if(strlen(i->msg) == 0 && strlen(i->text_0)==0){
    			        	strcat(i->text_0,"Wating for incoming data");}		
                        init_input_usr(i,w);}

                        
                        
    					break;
                   case SDLK_RETURN:


                         
                         if(strlen(i->msg)<(1024*1024) && strlen(i->msg) > 0){
                             i->index_word_bool = false;
                             memset(i->text_01,0,sizeof(i->text_01));
                             memset(i->text_0,0,sizeof(i->text_0));
                             snprintf(i->text_01,sizeof(i->text_01),"%s",i->msg);
                             snprintf(i->text_0,sizeof(i->text_0),"%s",i->msg);
                             memset(i->msg,0,sizeof(i->msg));
                             
                             command(i);
                             init_input_usr(i,w);}
                             break;}}
    			
    		else if(event.type == SDL_TEXTINPUT){
    		    
    			if(strlen(i->msg) + strlen(event.text.text) <1024 *1024 && !i->index_word_bool){
    			    size_t len_msg = strlen(i->msg);
    				size_t len_event_text = strlen(event.text.text);
    			    memcpy(&i->msg[len_msg],event.text.text,len_event_text);
    			    i->msg[len_msg + len_event_text] = '\0';
                    init_input_usr(i,w);}
 
                 
if(i->index_word_bool){
	printf("AQUI IRIA EL CODIGO DE PRUEBA...\n");
	paste_text(i->msg,event.text.text,&i->index_word_character);
		 			    int width,high;
	 			        char tmp_buffer[1024*1024];
	 			        memset(tmp_buffer,0,sizeof(tmp_buffer));
	 			        memcpy(tmp_buffer,i->msg,i->index_word_character);
	 			        ttf_size(w->font,tmp_buffer,&width,&high);
	 			        i->cursor_pos_x = i->rect.x + width+1;
	init_input_usr(i,w);}}}
        init_input_usr(i,w);
        init_draw(w,i);
        coord_mouse(w,i);
        
        SDL_Delay(16);}}
void coord_mouse(Window*w,Input_usr*i){
    int mouseX,mouseY;
	SDL_GetMouseState(&mouseX,&mouseY);}
void init_window(Window *window){
   SDL_Surface *icon = IMG_Load("icono_mapa.png");
  
   window->w = 1300;
   window->h = 700;
   window->title = " ";
   window->win = SDL_CreateWindow(window->title,600,5,window->w,window->h,SDL_WINDOW_SHOWN);
   SDL_SetWindowIcon(window->win,icon);
   SDL_FreeSurface(icon);
   window->render = SDL_CreateRenderer(window->win,-1,SDL_RENDERER_ACCELERATED);}


void init_draw(Window *window,Input_usr *i){
     SDL_Color c ={0,0,0,0};

     SDL_SetRenderDrawColor(window->render,c.r,c.g,c.b,c.a);
     SDL_RenderClear(window->render);

    if(window->texture !=NULL){
     	SDL_RenderCopy(window->render,window->texture,NULL,&(window->rect_font));
     }
     SDL_RenderCopy(window->render,i->texture,NULL,&(i->rect));
     cursor(i,window);
     SDL_RenderPresent(window->render);	
}


void init_font(Window *window,Input_usr *i){
    i->size_font = 18;
     window->font = TTF_OpenFont("font_3B.ttf",i->size_font);
     i->font = TTF_OpenFont("glitch.ttf",10);
     	    	
     if(window->font ==NULL){
     	printf("Error en cargar el archivo fuente \n");
     	return;
     }
     SDL_Color color = {0,255,0,255};
     window->surface = TTF_RenderText_Solid(window->font,"PLEASE INTRODUCE THE DATA..",color);
     if(!window->surface){printf("Error en crear superficie..\n");return;}
     window->texture = SDL_CreateTextureFromSurface(window->render,window->surface);
    //¿COMO ES POSIBLE QUE SE LIBERE EL SURFACE Y AUN ASI SE MUESTRE EN PANTALLA LA INFO DESPUED QUE SE LIBRA
     //PORQUE LA SUPERFICIE SE CARGA DENTRO DE EL RENDER
     window->rect_font.x =10;
     window->rect_font.y = 10;
     window->rect_font.w = window->surface->w;
     window->rect_font.h = window->surface->h;
     SDL_FreeSurface(window->surface);
     window->surface = NULL;
}
void init_input_usr(Input_usr *iu_,Window *w){

    Uint32 long_text = 1240;
    if(iu_->texture != NULL){
		SDL_DestroyTexture(iu_->texture);}
		if(strlen(iu_->msg)==0){
		    
		    iu_->rect.y = 35;
			iu_->surface = TTF_RenderText_Blended_Wrapped(w->font,iu_->text_0,(SDL_Color){255,250,255,0},long_text);
		}
		else{
			iu_->surface = TTF_RenderText_Blended_Wrapped(w->font,iu_->msg,(SDL_Color){255,240,120,0},long_text);
		}
		iu_->texture = SDL_CreateTextureFromSurface(w->render,iu_->surface);
		iu_->rect.w = iu_->surface->w;
		iu_->rect.h = iu_->surface->h;
		SDL_FreeSurface(iu_->surface);
	    iu_->surface = NULL;}

void cursor(Input_usr *i,Window *w){
	bool c_math  = ((SDL_GetTicks() /500) % 2)== 0;

	int text_width = 0;
	int text_high = 0;
    int  width = 0;
    int  high = 0;

   	if(strlen(i->msg) > 0 && !i->index_word_bool){
   	i->cursor_pos_x = i->rect.x;
    i->cursor_pos_y = i->rect.y;
    i->index_word_character = strlen(i->msg);
    TTF_SizeUTF8(w->font,i->msg,&text_width,&text_high);
    i->index_word = text_width;
    int limit = (text_width/ 1240 );
     
       if(i->cursor_pos_x < 1240){
       	i->cursor_pos_x += i->index_word;}
       	
       	if(i->cursor_pos_x >= 1240 && limit > 0) {
       		i->cursor_pos_x = text_width - (1240 * limit);
       		int index = i->cursor_pos_x + (1240 * limit);
       		i->cursor_pos_y += (18* limit);}}
       if(c_math && (strlen(i->msg) > 0)){
    	width = 8;
    	high  = (text_high>0)? text_high:18;}

    SDL_Rect rect = {i->cursor_pos_x,i->cursor_pos_y,width,high};
	SDL_SetRenderDrawColor(w->render,0,255,0,255);
	SDL_RenderFillRect(w->render,&rect);}
