 #include<stdlib.h>
 #include<stdio.h>
 #include<string.h>
 #include<stdint.h>
 #include<unistd.h>
 #include<libexif/exif-data.h>

 char *information(){
 char *file = NULL;
 
 	FILE *f ;
 	char p[1024];
 	memset(p,0,sizeof(p)); 
 	getcwd(p,sizeof(p));
 	printf("%s\n",p);
 	f = popen("ls","r");
 	if(!f){
 		printf("Cannot lunched the command ls\n");return file;}
 		char buffer[1024];
 		memset(buffer,0,sizeof(buffer));
 		while(fgets(buffer,sizeof(buffer),f) !=NULL){
 			char *elementos = strstr(buffer,".jpg");
 			if(elementos !=NULL){
 			    char buffer_tmp[100];
 			    memset(buffer_tmp,0,sizeof(buffer_tmp));
 			    snprintf(buffer_tmp,sizeof(buffer_tmp),"%s/%s",p,buffer);
 			    strcpy(f,buffer_tmp);
 				printf("File founded %s\n",file);
                	pclose(f);
                    return file;
 			}
 		}
 		return file;
 		pclose(f);
 }


void data(const char *path){
	ExifData *d = exif_data_new_from_file(path);
	if(d == NULL){
		printf("simething went wrong\n");
	}
	//if(d->data != NULL)	printf("%s\n",d->data);
	
}

 int main ()
 {   

    printf("Compilation correct!!\n");
    char *info = NULL;


    info = information();

    if(info!= NULL){
    const char *p = strdup(info);	
    data(p);
    
    printf("%s\n",info);}
 	return 0;
 }
