#include<SDL2/SDL.h>
#include<SDL2/SDL_ttf.h>
#include<SDL2/SDL_image.h>
#include<ctype.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<stdbool.h>
#include<stdint.h>
#include<string.h>
#include<errno.h>
#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<libexif/exif-data.h>//PARA INSTALAR LA LIBRERIA EXIFTOOL : sudo apt install libexif-dev
#ifndef LIBRARY_H
#define LIBRARY_H
#define RADIO_TIERRA_M 6371000.0 // Radio medio de la Tierra en metros
#define TO_RAD (3.14159265358979323846 / 180.0)
#define PUNTO 10
#define CALLE 100.0
#define BARRIO 1000.0
#define CIUDAD 15000.0
#define PROVINCIA 100000.0


typedef struct{
	double punto;
	double calle;
	double barrio;
	double ciudad;
	double provincia;
}Umbral_distance;

typedef struct{
	SDL_Window *win;
	SDL_Renderer *render;
	SDL_Rect rect_font;
    TTF_Font *font;
    SDL_Surface *surface;
    SDL_Texture *texture;
	const char *title;
	int run;
	int w;
	int h;
}Window;
typedef struct{
    Umbral_distance point;
	char msg[1024 * 1024];
	SDL_Rect rect;
	TTF_Font *font;
	SDL_Texture *texture;
	SDL_Surface *surface;
	int *run;
	int status;
	int size_font;
	char text_0[1024*1024*1024];
    char text_01[1024*1024];
	char path_[1000];
	char name_Folder[20];
	double lat2;
	double lon2;
	double range;
	double resultado;
	int cursor_pos_x;
	int cursor_pos_y;
	int index_word;
	int index_word_character;
	bool index_word_bool;
	
}Input_usr;
int program_init(Input_usr*);
void init_window(Window*);
void init_draw(Window*,Input_usr*);
void init_event(Window*,Input_usr*);
void init_font(Window*,Input_usr*);
void init_input_usr(Input_usr *iu_,Window *w);
void exec_program(Input_usr *i);
void ifis_dir(Input_usr *,char*);
void cursor(Input_usr*,Window*);
void coord_mouse(Window*,Input_usr*);
void telemetria(Input_usr*);
void take_off_sign(double*);
void ttf_size(TTF_Font*,char*,int*,int*);
void paste_text(char *,char *,int*);
int command(Input_usr*);
uint8_t path_directory(const char *);
int create_folder(char*);
int copy_file(char *,char *);
int getting_gps(const char*,double*,double*);
int comparassion_distance(Input_usr *i);
double make_count_gps(double ,double,double,double);
#endif
