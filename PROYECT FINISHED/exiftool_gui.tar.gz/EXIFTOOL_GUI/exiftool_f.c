#include "library.h"
#include "exiftool.h"

double double_convert(ExifRational *r) {
	if(r->denominator == 0.0)return 0.0;
	return (double)r->numerator / (double)r->denominator;
}

int getting_gps(const char *path,double *latitud,double *longitud){ //ESTA FUNCION ES MODULAR
   
	ExifData *data = exif_data_new_from_file(path);
		
	if(!data){	
	    
		printf("We cannot get info from the pathfile :%s\n",path);
		return 0;
	}
	ExifContent *gps_content = data->ifd[EXIF_IFD_GPS];
	if(!gps_content){
	exif_data_unref(data);
    printf("No GPS IFD content in file: %s\n", path);
	return 0;}

    ExifEntry *e_lat = exif_content_get_entry(gps_content,EXIF_TAG_GPS_LATITUDE);
    ExifEntry *e_lat_ref = exif_content_get_entry(gps_content,EXIF_TAG_GPS_LATITUDE_REF);
    ExifEntry *e_lon = exif_content_get_entry(gps_content,EXIF_TAG_GPS_LONGITUDE);
    ExifEntry *e_lon_ref = exif_content_get_entry(gps_content,EXIF_TAG_GPS_LONGITUDE_REF);
    if(!e_lat || !e_lat_ref||!e_lon||!e_lon_ref){
    	printf("Could nt obtain data from the file ..\n");
    	exif_data_unref(data);return 0;}

    ExifRational *lat_val = (ExifRational *)e_lat->data;
    ExifRational *lon_val = (ExifRational *)e_lon->data;	

    double lat_g = double_convert(&lat_val[0]);
    double lat_m = double_convert(&lat_val[1]);
    double lat_s = double_convert(&lat_val[2]);

    double lon_g = double_convert(&lon_val[0]);
    double lon_m = double_convert(&lon_val[1]);
    double lon_s = double_convert(&lon_val[2]);
        
    *latitud = lat_g + (lat_m / 60.0) + (lat_s / 3600.0);
    *longitud = lon_g + (lon_m / 60.0) + (lon_s / 3600.0);
    if (e_lat_ref->data[0] == 'S') *latitud = -(*latitud);
    if (e_lon_ref->data[0] == 'W') *longitud = -(*longitud);
	exif_data_unref(data);
	return 1;
}

int comparassion_distance(Input_usr *i){
	if(i->range > i->resultado && i->range < i->point.punto){return 1;}
    if(i->range > i->resultado && i->range < i->point.calle){return 1;}
   	if(i->range > i->resultado && i->range < i->point.barrio){return 1;}
    if(i->range > i->resultado && i->range < i->point.ciudad){return 1;}
    if(i->range > i->resultado && i->range < i->point.provincia){return 1;}
    return 0;}

double make_count_gps(double lat1,double lon1,double lat2,double lon2){
	double dLat = (lat1 - lat2) * TO_RAD;
	double dLon = (lon1 - lon2) * TO_RAD;

	double a = sin(dLat / 2.0) * sin(dLat / 2.0) +
	               cos(lat1 * TO_RAD) * cos(lat2 * TO_RAD) *
	               sin(dLon / 2.0) * sin(dLon / 2.0);
	double c = 2.0 * atan2(sqrt(a), sqrt(1.0 - a));
	
	return RADIO_TIERRA_M * c;
}



void ifis_dir(Input_usr *ii,char *i){
   //const char* constructor = strdup(i);
   double resultado = 0.0;
   char clear[1024];memset(clear,0,sizeof(clear));
   char trash[2];
   char *copy_i;
   int count = sscanf(ii->text_01,"%s %1s",clear,trash);
   if(count == 1){
      copy_i = strdup(i); 	
   }
   if(count == 2){
   	 copy_i = strdup(clear);}
   
   FILE *f;
   char command[1024*1024];
   memset(command,0,sizeof(command));
   snprintf(command,sizeof(command),"ls %s",copy_i);
   printf("%s\n",command);
   f = popen(command,"r");
   if(f == NULL){return;}
   char buffer[1024];
   memset(buffer,0,sizeof(buffer));
   memset(ii->text_0,0,sizeof(ii->text_0));

   char abs_path[(sizeof(buffer) + sizeof(clear))];
   memset(abs_path,0,sizeof(abs_path));
   
   double lat,lon,lat2,lon2;
   snprintf(ii->name_Folder,sizeof(ii->name_Folder),"Respaldo");
   int status_folder = create_folder(ii->name_Folder);
   if(!status_folder){snprintf(ii->text_0,sizeof(ii->text_0),"ERROR TO CREATE THE FOLDERS`NAME : %s",ii->name_Folder);return;};
   char file_new[2048];memset(file_new,0,sizeof(file_new));
   while(fgets(buffer,sizeof(buffer),f) != NULL){
    memset(abs_path,0,sizeof(abs_path));
   
    snprintf(abs_path,sizeof(abs_path),"%s/%s",clear,buffer);
    abs_path[strcspn(abs_path,"\n")] = '\0';
    const char *path = strdup(abs_path);
    if((path_directory(path) == 8)){
        
        int gps_status = getting_gps(abs_path,&lat,&lon);
    	if(gps_status >0){
    	      char final_[1024 * 1024];
    	      memset(final_,0,sizeof(final_));
    	     
    	      if(count == 2){resultado = make_count_gps(lat,lon,ii->lat2,ii->lon2);
    	      ii->resultado = resultado;
                   
    	      int s_comparassion = comparassion_distance(ii);
              if(s_comparassion){
                     
             snprintf(file_new,sizeof(file_new),"%s/%s",ii->name_Folder,buffer);
             file_new[strcspn(file_new,"\n")] = '\0';
             int status_copy_file = copy_file(abs_path,file_new);
             if(!status_copy_file){strcat(ii->text_0,"NO SE PUDO COPIAR EL ARCHIVO");}}}
    	      snprintf(final_,sizeof(final_),"FILE ---> %s LATITUD: [%f] LONGITUD: [%f]",buffer,lat,lon);
    		  snprintf(ii->text_0,sizeof(ii->text_0),"%s",final_);}
    	if(gps_status ==0){
    		char final_[1024 * 1024];
    		memset(final_,0,sizeof(final_));
    		snprintf(final_,sizeof(final_),"NO INFO  ----> %s",buffer);
    		strcat(ii->text_0,final_);
    	}}
    abs_path[strlen(abs_path)]='\n';
    strcat(ii->text_0,abs_path);}
  
   
   if(f!=NULL){
   	pclose(f);}}
uint8_t path_directory(const char *path){ 
   struct stat info;
   
   if(stat(path,&info) != 0){
   	      return 0x0;}
   uint8_t i = ((info.st_mode)& 0xf000) >> 12;
   return i;}
void exec_program(Input_usr *i){
    double lat;
    double lon;
    
    const char *p = strdup(i->text_01);
    uint8_t status_path = path_directory(i->text_01);
    

    switch(status_path){
         case 4: //PATH DIRECTORY
            ifis_dir(i,i->text_01);
            break;
         case 8:{//FILE 
         	  int gps_status = getting_gps(i->text_01,&lat,&lon);
         	  if(gps_status > 0){
         	   snprintf(i->text_0,sizeof(i->text_0),"FILE ---> %s LATITUD: [%f] LONGITUD: [%f]",p,lat,lon);}
              if(gps_status == 0){
              snprintf(i->text_0,sizeof(i->text_0),"Cannot get info about **** %s ****\nPLEASE TYPE help FOR MORE INFORMATION",i->text_01);
              }


         	  break;}
         default:{
         	snprintf(i->text_0,sizeof(i->text_0),"Cannot get info about **** %s ****\nPLEASE TYPE help FOR MORE INFORMATION",i->text_01);
         	break;}
    
    	      }
    
    
    }



    
 void telemetria(Input_usr *i){
 
 char trash[2];
 char obj_ref[1024];memset(obj_ref,0,sizeof(obj_ref));
int count = sscanf(i->text_0,"%s -p %lf %lf -r %lf %1s",obj_ref,&i->lat2,&i->lon2,&i->range,trash);
 if(count != 4){
 	snprintf(i->text_0, sizeof(i->text_0), 
 	            "THE NUMBER OF PARAMETERS IS NOT VALID TYPE :\n"
 	            " -p longitude latitude -r range EXAMPLE \n\n"
 	            " (NAME_FILE OR DIRECTORY) -p 43.233232 55.34343 -r 500");return;}
else{
    
    uint8_t valid = path_directory(obj_ref);
    if(valid == 8){
      snprintf(i->text_0, sizeof(i->text_0), "***%s*** IS FILE : 0x%02X",obj_ref,valid);
      return;}
      else if(valid == 4){
      ifis_dir(i,i->text_01);
      return; }
else{ 
      snprintf(i->text_0, sizeof(i->text_0), "***%s*** IS NOT A FILE O DIRECTORY RESULT : 0x%02X",obj_ref,valid);
      return;}}	
 	}   
int create_folder(char *name_folder){//ESTA FUNCION ES MODULAR
  	if(mkdir(name_folder,0755) == 0){
  		return 1; }
  	if(errno == EEXIST){
  		return 1;}
   else{return 0;}}

void take_off_sign(double *f_){
	*f_ = fabs(*f_);}
int comparassion(double *a,double *b,double *y,double *z,double range){ 
	*a = fabs(*a);*b = fabs(*b);*y = fabs(*y);*z = fabs(*z);
    if((*a - *y) > range || (*b - *z) > range)return  0;
    return 1;}

    
int copy_file(char *src,char *dst){ 
	FILE *f_src,*f_dst;
	f_src = fopen(src,"rb");
	f_dst = fopen(dst,"wb");
	if(f_src == NULL || f_dst == NULL)return 0;

   char buffer[1024];memset(buffer,0,sizeof(buffer));
   size_t tam;
   while((tam = fread(buffer,1,sizeof(buffer),f_src)) > 0){
   	     fwrite(buffer,1,tam,f_dst);}
   if(f_src != NULL) free(f_src);
   if(f_dst != NULL) free(f_dst);
   return 1;
       }



int command(Input_usr *i){
  char *c_help = "help";
  char *c_options = "-p";
  char *c_exit = "exit";
  char *c_current = "*.jpg";
  
  char *result_help = strstr(i->text_0,c_help);
  char *result_options = strstr(i->text_0,c_options);
  char *result_exit = strstr(i->text_0,c_exit);
  char *result_current = strstr(i->text_0,c_current);
  if(result_current != NULL){
  memset(i->text_01,0,sizeof(i->text_01));
  memset(i->text_0,0,sizeof(i->text_0));
  	strcat(i->text_01,".");
  	strcat(i->text_0,".");
  	exec_program(i);
  	return 1;
  }
 if(result_exit != NULL){
    
  	*i->run = 0;
  }
  
  
  
  if(result_help != NULL){
  printf("coincidencia encontrada \n");
    
  	strcpy(i->text_0,"[+]WRITE  JUST THE NAME OF THE FILE IF YOU WANNA SEE THE METADATA");
  	strcat(i->text_0,"\nEXAMPLE.. NAME_FILE.jpg");
    strcat(i->text_0,"\n\n[+]IF YOU WANT SEE ALL THE METADATA INTO TO SOME KIND OF DIRECTORY.. ");
    strcat(i->text_0,"\nTYPE  *.jpg");
    strcat(i->text_0,"\n\n[+]FOR THE EXIT PLEASE TYPE exit OR PULSE ESC ....");
    return 0;
  }
  else if(result_options != NULL){
    telemetria(i);

    
  	return 0;}	
  else {  
      
      exec_program(i);
      return 1;}
}




