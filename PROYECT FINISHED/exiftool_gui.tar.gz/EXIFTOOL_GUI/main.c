#include "library.h"
int main(){

    const char *path = "/home/lisandro/Imágenes/Camera";
    /*double latitud,longitud;
    getting_gps(path,&latitud,&longitud);
    printf("LATITUD : %f LONGITUD : %f\n",latitud,longitud);
    return 0;
   int nu = path_directory(path);
   printf("%d\n",nu);
   return 0;*/
   if(SDL_Init(SDL_INIT_EVERYTHING) <0){
   	printf("No se puedo crear SDL_VIDEO\n");
   	return -1;}
   	if (TTF_Init() == -1) {
   	    printf("No se pudo inicializar SDL_ttf: %s\n", TTF_GetError());
   	    return 1;
   	}
   	if (!(IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG)) {
   	    printf("Error: %s\n", IMG_GetError());
   	    return 1;
   	}
   Window *w_ = calloc(1,sizeof(Window));
   Input_usr *iu = calloc(1,sizeof(Input_usr));
   iu->point =(Umbral_distance){PUNTO,CALLE,BARRIO,CIUDAD,PROVINCIA};
   
   init_window(w_);
   init_font(w_,iu); 
   init_event(w_,iu);


   SDL_DestroyTexture(w_->texture);
   SDL_DestroyTexture(iu->texture);
   TTF_CloseFont(w_->font);
   TTF_CloseFont(iu->font);
   SDL_DestroyWindow(w_->win);
   SDL_DestroyRenderer(w_->render);
   TTF_Quit();
   SDL_Quit();
   free(w_);
   free(iu);
	return 0;
}
