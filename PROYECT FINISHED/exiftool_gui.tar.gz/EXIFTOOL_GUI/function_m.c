#include"library.h"
//HERE ONLY GOES THE MODULAR FUNCTIONS
void ttf_size(TTF_Font *f,char *ch,int *width,int *high){
	TTF_SizeUTF8(f,ch,width,high);
}
void paste_text(char *old_elements,char *new_elements,int *index){
      size_t len_new = strlen(new_elements);
      size_t len_old = strlen(old_elements);
      memmove(&old_elements[*index+len_new],&old_elements[*index],len_old-*index+1);
      memcpy(&old_elements[*index],new_elements,len_new);
      old_elements[len_old+len_new]='\0';
      (*index)++;}
